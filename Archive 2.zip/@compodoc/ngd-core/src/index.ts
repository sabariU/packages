export {
  logger
} from './lang/logger';
export {
  compilerHost,
  d,
  getNewLineCharacter
} from './lang/utilities';
