export interface MiscellaneousData {
    variables;
    functions;
    typealiases;
    enumerations;
    groupedVariables;
    groupedFunctions;
    groupedEnumerations;
    groupedTypeAliases;
}
