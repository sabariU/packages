# Installation
> `npm install --save @types/leaflet`

# Summary
This package contains type definitions for Leaflet.js (https://github.com/Leaflet/Leaflet).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/leaflet

Additional Details
 * Last updated: Thu, 30 Nov 2017 21:46:00 GMT
 * Dependencies: geojson
 * Global values: L

# Credits
These definitions were written by Alejandro Sánchez <https://github.com/alejo90>, Arne Schubert <https://github.com/atd-schubert>.
