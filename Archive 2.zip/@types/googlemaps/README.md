# Installation
> `npm install --save @types/googlemaps`

# Summary
This package contains type definitions for Google Maps JavaScript API (https://developers.google.com/maps/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/googlemaps

Additional Details
 * Last updated: Tue, 02 Jan 2018 20:47:02 GMT
 * Dependencies: none
 * Global values: google

# Credits
These definitions were written by Folia A/S <http://www.folia.dk>, Chris Wrench <https://github.com/cgwrench>, Kiarash Ghiaseddin <https://github.com/Silver-Connection/DefinitelyTyped>,  Grant Hutchins <https://github.com/nertzy>, Denis Atyasov <https://github.com/xaolas>, Michael McMullin <https://github.com/mrmcnerd>, Martin Costello <https://github.com/martincostello>, Sven Kreiss <https://github.com/svenkreiss>.
