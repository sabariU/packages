# Installation
> `npm install --save @types/geojson`

# Summary
This package contains type definitions for geojson (https://geojson.org/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/geojson

Additional Details
 * Last updated: Mon, 29 Jan 2018 21:19:39 GMT
 * Dependencies: none
 * Global values: GeoJSON

# Credits
These definitions were written by Jacob Bruun <https://github.com/cobster>, Arne Schubert <https://github.com/atd-schubert>, Jeff Jacobson <https://github.com/JeffJacobson>.
