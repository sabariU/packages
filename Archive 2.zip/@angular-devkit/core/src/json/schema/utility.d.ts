import { JsonSchema } from './schema';
export declare function getTypesOfSchema(schema: JsonSchema): Set<string>;
