import { JsonObject } from '@angular-devkit/core';
import { Schema as ExtractI18nBuilderOptions } from './schema';
declare const _default: import("@angular-devkit/architect/src/internal").Builder<JsonObject & ExtractI18nBuilderOptions>;
export default _default;
