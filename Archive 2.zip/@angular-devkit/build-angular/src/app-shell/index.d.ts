import { JsonObject } from '@angular-devkit/core';
import { Schema as BuildWebpackAppShellSchema } from './schema';
declare const _default: import("@angular-devkit/architect/src/internal").Builder<JsonObject & BuildWebpackAppShellSchema>;
export default _default;
